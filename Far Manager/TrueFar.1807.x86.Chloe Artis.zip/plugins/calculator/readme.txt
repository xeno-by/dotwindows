
Plugin Calculator for FAR Manager v3.10   (c) Cail Lomecb 1998-2001
                                          (c) uncle-vunkis 2009
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

How you can install this plugin?

1.  Create subdirectory \Far\PlugIns\Calculator
    and copy there all calculator files.
2.  Restart FAR Manager and Calculator is ready for work:
    F11 (plugins Menu) - Calculator.

    This     PlugIn     is    distributed    as    an    EmailWare
program.  It  Means,  that  you  can  Freely  use Calculator after
sending  me  filled  EMailForm  (if  you  have  EMail). More about
registration in regform.txt file.

    ������ My address ������
    Russia, Shakhunia.
      Nizhegorodskiy region. 606910,
      Chapaeva st, 3-15. Tel: (831-52) 2-16-56.
      Igor Ruskih.
    ������ EMail ������
    ruiv@uic.nnov.ru (lomecb@chat.ru)
      New versions of calculator and my
      other programs you'll find in:
      http://www.uic.nnov.ru/~ruiv/  (http://www.chat.ru/~lomecb/)
      http://www.uic.nnov.ru/~ruiv/plugring/

                                                       Cail Lomecb