﻿Для справки используйте "bci.exe /?"

Все ошибки сообщать на форуме:
"http://forum.farmanager.com/viewtopic.php?f=8&t=277&start=90&hilit=bci"
