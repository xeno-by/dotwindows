﻿svcmgr: Manage services FAR plugin

Allow to manage windows services

TODO:
Пока не работает диалог изменения зависимостей сервиса, доделаю когда-нибудь

Спасибо за русский lng файл:
VictorVG @ VikSoft.Ru

© 2010 Andrew Grechkin
	mailto: andrew.grechkin@gmail.com
	jabber: andrew.grechkin@gmail.com

Исходный код
	http://code.google.com/p/andrew-grechkin
