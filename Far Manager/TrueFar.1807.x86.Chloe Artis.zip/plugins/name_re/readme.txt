NameRe 1.5.2
------------

What's New
----------

Plugin now fully supports long paths (ie. > 256 characters).

Plugin now works with FAR Manager 2.0 build 1145+!

Added two more edit mode plugins for resetting current/all items back to original names.

Description
-----------

NameRe is a batch rename tool that can manipulate the existing names or construct new 
name sequences. It also allows for changing the names of selected items manually using the
FAR internal editor.

NameRe is able to rename both files and folders. The plugin can be configured to perform 
rename operations on files only, or on both files and folders.

NameRe provides for renaming items using two separate modules: Manipulate and Construct. 
It also provides an 'Edit Mode' which puts all selected item's names in the editor so 
that they can be changed manually. Manipulate and Construct are provided as separate 
dialogs and, depending on the configuration, these can be accessed separately from the 
plugin menu or as a single entry which will open a specific dialog (or the last one used).
It is also possible to switch between the dialogs at will. 'Edit Mode' can only be accessed
from the plugin menu (as a separate entry; if enabled in the configuration).

The Manipulate component allows for adding a prefix and/or suffix, removing characters 
from the start and/or end, or replacing parts of the existing names of selected items.
It can also do case changes and allows extensions to be added or replaced (or removed 
completely).

The Construct component allows for constructing new names for items using a template.
The template can make use of the existing name and extension, static characters, as 
well as number sequences (which increment for each selected item). For files, the 
template can specify the name only, ie. preserving the existing extensions of items, 
or by using the template to specify the entire new name including extensions if required. 
For folders, the template always specifies the entire name since extensions aren't applicable.

'Edit Mode' puts the names of selected items into the FAR internal editor and allows the 
user to change them freely. Each line in the editor corresponds to a single selected item 
that can be changed as required, or ignored completely (leaving the original name unchanged). 
However, adding or removing lines will cause an error message to be displayed, in which case 
the user can return to the editor to fix the problem, or cancel the operation. After all 
changes are made, the file should be saved (F2 by default) and the editor closed.  This will 
validate the file, prompt for action if a problem is found, or start the rename operation. If 
the editor is closed without changing the file, no action is taken on the selected items.

When the editor is open for a NameRe 'Edit Mode' operation, two editor plugins are provided: 
Single and Multi. These display the original names for the current line in the editor, or for
all visible lines (respectively) to aid with renaming.

In addition, the plugin allows for rolling back any rename operations (as long as the summary
display is enabled).


Enjoy the plugin
free3dom

4 October 2009
