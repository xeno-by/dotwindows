** Hexitor PlugIn (for Far 2.0) **

This plugin for Far 2.0 allows you to edit file in hex format.

Install:
Unpack the archive to the Far plugins directory (...Far\Plugins).

Artem A. Senichev (artemsen@gmail.com)
                  http://code.google.com/p/farplugs
